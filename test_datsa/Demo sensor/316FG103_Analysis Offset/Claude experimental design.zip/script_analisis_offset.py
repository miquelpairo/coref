"""
Script de Análisis: Impacto de Offset en Predicciones NIR
==========================================================

Procesa datos de múltiples niveles de offset y analiza el impacto
en predicciones analíticas.

Autor: Miquel
Fecha: Diciembre 2025
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from pathlib import Path

class OffsetImpactAnalyzer:
    """
    Analizador de impacto de offset en predicciones NIR
    """
    
    def __init__(self, data_file, output_dir='outputs'):
        """
        Inicializa el analizador
        
        Parameters:
        -----------
        data_file : str
            Ruta al archivo con datos (Excel con sheets por offset)
        output_dir : str
            Directorio para guardar resultados
        """
        self.data_file = data_file
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        self.data = {}
        self.offsets = []
        self.productos = []
        self.parametros = []
        
    def load_data(self):
        """
        Carga datos desde archivo Excel
        
        Formato esperado:
        - Cada sheet = un nivel de offset
        - Nombre sheet: "offset_0.000", "offset_0.005", etc.
        - Columnas: ID, Producto, Param1, Param2, ..., ParamN
        """
        print("Cargando datos...")
        
        # Leer todos los sheets
        xls = pd.ExcelFile(self.data_file)
        
        for sheet_name in xls.sheet_names:
            if sheet_name.startswith('offset_'):
                # Extraer valor de offset del nombre
                offset = float(sheet_name.split('_')[1])
                self.offsets.append(offset)
                
                # Cargar datos
                df = pd.read_excel(xls, sheet_name)
                self.data[offset] = df
                
                # Guardar listas de productos y parámetros (primera vez)
                if not self.productos:
                    self.productos = df['Producto'].unique().tolist()
                if not self.parametros:
                    exclude = ['ID', 'Producto', 'Muestra']
                    self.parametros = [c for c in df.columns if c not in exclude]
        
        self.offsets.sort()
        print(f"✓ Cargados {len(self.offsets)} niveles de offset")
        print(f"✓ Productos: {len(self.productos)}")
        print(f"✓ Parámetros: {len(self.parametros)}")
        
    def calculate_differences(self):
        """
        Calcula diferencias respecto al offset de referencia (0.000)
        """
        print("\nCalculando diferencias...")
        
        # Referencia = offset 0
        if 0.0 not in self.offsets:
            raise ValueError("Se requiere medición con offset=0.000 como referencia")
        
        df_ref = self.data[0.0]
        
        # Preparar estructura de resultados
        results = []
        
        for offset in self.offsets:
            if offset == 0.0:
                continue
                
            df_test = self.data[offset]
            
            for producto in self.productos:
                df_ref_prod = df_ref[df_ref['Producto'] == producto]
                df_test_prod = df_test[df_test['Producto'] == producto]
                
                if len(df_ref_prod) == 0 or len(df_test_prod) == 0:
                    continue
                
                for param in self.parametros:
                    try:
                        ref_vals = pd.to_numeric(df_ref_prod[param], errors='coerce').dropna()
                        test_vals = pd.to_numeric(df_test_prod[param], errors='coerce').dropna()
                        
                        if len(ref_vals) > 0 and len(test_vals) > 0:
                            ref_mean = ref_vals.mean()
                            test_mean = test_vals.mean()
                            diff_abs = abs(test_mean - ref_mean)
                            diff_rel = 100 * diff_abs / ref_mean if ref_mean != 0 else 0
                            
                            results.append({
                                'Offset': offset,
                                'Producto': producto,
                                'Parametro': param,
                                'Ref_mean': ref_mean,
                                'Test_mean': test_mean,
                                'Diff_abs': diff_abs,
                                'Diff_rel': diff_rel
                            })
                    except Exception as e:
                        continue
        
        self.results = pd.DataFrame(results)
        print(f"✓ Calculadas {len(self.results)} diferencias")
        
        # Guardar resultados
        output_file = self.output_dir / 'diferencias_detalladas.xlsx'
        self.results.to_excel(output_file, index=False)
        print(f"✓ Guardado: {output_file}")
        
    def analyze_impact(self):
        """
        Analiza el impacto por nivel de offset
        """
        print("\nAnalizando impacto...")
        
        summary = []
        
        for offset in self.offsets:
            if offset == 0.0:
                continue
            
            df_offset = self.results[self.results['Offset'] == offset]
            
            summary.append({
                'Offset': offset,
                'N_params': len(df_offset),
                'Diff_mean': df_offset['Diff_rel'].mean(),
                'Diff_median': df_offset['Diff_rel'].median(),
                'Diff_std': df_offset['Diff_rel'].std(),
                'Diff_max': df_offset['Diff_rel'].max(),
                'Pct_02': 100 * (df_offset['Diff_rel'] < 0.2).sum() / len(df_offset),
                'Pct_03': 100 * (df_offset['Diff_rel'] < 0.3).sum() / len(df_offset),
                'Pct_05': 100 * (df_offset['Diff_rel'] < 0.5).sum() / len(df_offset)
            })
        
        self.summary = pd.DataFrame(summary)
        
        # Guardar resumen
        output_file = self.output_dir / 'resumen_por_offset.xlsx'
        self.summary.to_excel(output_file, index=False)
        print(f"✓ Guardado: {output_file}")
        
        # Mostrar resumen
        print("\nRESUMEN POR OFFSET:")
        print("="*80)
        print(self.summary.to_string(index=False))
        
    def find_breakpoint(self, threshold=0.2, min_percentage=75):
        """
        Encuentra el punto de quiebre donde se excede el umbral
        
        Parameters:
        -----------
        threshold : float
            Diferencia máxima aceptable (%)
        min_percentage : float
            Porcentaje mínimo de parámetros que deben cumplir
        """
        print(f"\nBuscando punto de quiebre (>{threshold}% en >{min_percentage}% params)...")
        
        acceptable_offsets = []
        
        for _, row in self.summary.iterrows():
            if threshold == 0.2:
                pct = row['Pct_02']
            elif threshold == 0.3:
                pct = row['Pct_03']
            else:
                # Calcular custom
                df_offset = self.results[self.results['Offset'] == row['Offset']]
                pct = 100 * (df_offset['Diff_rel'] < threshold).sum() / len(df_offset)
            
            if pct >= min_percentage:
                acceptable_offsets.append(row['Offset'])
                print(f"  Offset {row['Offset']:.3f}: {pct:.1f}% parámetros <{threshold}% ✓")
            else:
                print(f"  Offset {row['Offset']:.3f}: {pct:.1f}% parámetros <{threshold}% ✗ QUIEBRE")
                break
        
        if acceptable_offsets:
            max_acceptable = max(acceptable_offsets)
            print(f"\n✓ Offset máximo aceptable: {max_acceptable:.3f}")
            return max_acceptable
        else:
            print("\n✗ Ningún offset cumple criterio")
            return None
    
    def plot_main_curve(self):
        """
        Gráfico principal: Offset vs Diferencia
        """
        print("\nGenerando gráfico principal...")
        
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        # 1. Diferencia promedio por offset
        ax = axes[0, 0]
        ax.plot(self.summary['Offset'], self.summary['Diff_mean'], 
               'o-', linewidth=3, markersize=10, color='#3498db', label='Media')
        ax.plot(self.summary['Offset'], self.summary['Diff_median'],
               's--', linewidth=2, markersize=8, color='#e74c3c', label='Mediana')
        ax.axhline(y=0.2, color='red', linestyle='--', linewidth=2, alpha=0.5, label='Límite 0.2%')
        ax.axhline(y=0.3, color='orange', linestyle='--', linewidth=2, alpha=0.5, label='Límite 0.3%')
        ax.fill_between(self.summary['Offset'], 0, 0.2, alpha=0.1, color='green', label='Zona aceptable')
        ax.set_xlabel('Offset', fontweight='bold', fontsize=12)
        ax.set_ylabel('Diferencia en predicciones (%)', fontweight='bold', fontsize=12)
        ax.set_title('Impacto Global de Offset', fontsize=14, fontweight='bold')
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        
        # 2. Porcentaje de parámetros <límite
        ax = axes[0, 1]
        ax.plot(self.summary['Offset'], self.summary['Pct_02'],
               'o-', linewidth=3, markersize=10, color='#27ae60', label='<0.2%')
        ax.plot(self.summary['Offset'], self.summary['Pct_03'],
               's-', linewidth=3, markersize=10, color='#f39c12', label='<0.3%')
        ax.plot(self.summary['Offset'], self.summary['Pct_05'],
               '^-', linewidth=3, markersize=10, color='#e74c3c', label='<0.5%')
        ax.axhline(y=75, color='gray', linestyle='--', linewidth=1.5, alpha=0.5)
        ax.set_xlabel('Offset', fontweight='bold', fontsize=12)
        ax.set_ylabel('% parámetros', fontweight='bold', fontsize=12)
        ax.set_title('Porcentaje de Parámetros Aceptables', fontsize=14, fontweight='bold')
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.set_ylim(0, 105)
        
        # 3. Diferencia máxima
        ax = axes[1, 0]
        ax.plot(self.summary['Offset'], self.summary['Diff_max'],
               'o-', linewidth=3, markersize=10, color='#e74c3c')
        ax.axhline(y=0.5, color='red', linestyle='--', linewidth=2, alpha=0.5)
        ax.set_xlabel('Offset', fontweight='bold', fontsize=12)
        ax.set_ylabel('Diferencia máxima (%)', fontweight='bold', fontsize=12)
        ax.set_title('Peor Caso por Offset', fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3)
        
        # 4. Distribución (box plot)
        ax = axes[1, 1]
        box_data = [self.results[self.results['Offset'] == offset]['Diff_rel'].values 
                   for offset in self.offsets if offset > 0]
        box_positions = [offset for offset in self.offsets if offset > 0]
        bp = ax.boxplot(box_data, positions=box_positions, widths=0.002,
                       patch_artist=True, showmeans=True)
        
        for patch in bp['boxes']:
            patch.set_facecolor('#3498db')
            patch.set_alpha(0.6)
        
        ax.axhline(y=0.2, color='red', linestyle='--', linewidth=2, alpha=0.5)
        ax.axhline(y=0.3, color='orange', linestyle='--', linewidth=2, alpha=0.5)
        ax.set_xlabel('Offset', fontweight='bold', fontsize=12)
        ax.set_ylabel('Diferencia (%)', fontweight='bold', fontsize=12)
        ax.set_title('Distribución de Diferencias', fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3, axis='y')
        
        plt.tight_layout()
        output_file = self.output_dir / 'analisis_offset_principal.png'
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        print(f"✓ Guardado: {output_file}")
        plt.close()
    
    def plot_by_product(self):
        """
        Gráfico por producto
        """
        print("\nGenerando gráfico por producto...")
        
        fig, axes = plt.subplots(2, 3, figsize=(20, 12))
        axes = axes.flatten()
        
        colors = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6']
        
        for idx, producto in enumerate(self.productos):
            ax = axes[idx]
            
            df_prod = self.results[self.results['Producto'] == producto]
            
            # Agrupar por offset
            prod_summary = df_prod.groupby('Offset').agg({
                'Diff_rel': ['mean', 'std', 'max']
            }).reset_index()
            prod_summary.columns = ['Offset', 'Mean', 'Std', 'Max']
            
            ax.plot(prod_summary['Offset'], prod_summary['Mean'],
                   'o-', linewidth=3, markersize=8, color=colors[idx], label='Media')
            ax.fill_between(prod_summary['Offset'],
                          prod_summary['Mean'] - prod_summary['Std'],
                          prod_summary['Mean'] + prod_summary['Std'],
                          alpha=0.2, color=colors[idx])
            
            ax.axhline(y=0.2, color='red', linestyle='--', linewidth=1.5, alpha=0.5)
            ax.axhline(y=0.3, color='orange', linestyle='--', linewidth=1.5, alpha=0.5)
            
            ax.set_xlabel('Offset', fontweight='bold')
            ax.set_ylabel('Diferencia (%)', fontweight='bold')
            ax.set_title(f'{producto}', fontsize=12, fontweight='bold')
            ax.grid(True, alpha=0.3)
        
        # Eliminar axes sobrantes
        for idx in range(len(self.productos), len(axes)):
            fig.delaxes(axes[idx])
        
        plt.suptitle('Impacto de Offset por Producto', fontsize=16, fontweight='bold')
        plt.tight_layout()
        
        output_file = self.output_dir / 'analisis_offset_por_producto.png'
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        print(f"✓ Guardado: {output_file}")
        plt.close()
    
    def plot_heatmap(self):
        """
        Heatmap: Producto × Offset
        """
        print("\nGenerando heatmap...")
        
        # Preparar matriz
        pivot_data = self.results.groupby(['Producto', 'Offset'])['Diff_rel'].mean().reset_index()
        pivot_table = pivot_data.pivot(index='Producto', columns='Offset', values='Diff_rel')
        
        fig, ax = plt.subplots(figsize=(14, 6))
        
        sns.heatmap(pivot_table, annot=True, fmt='.3f', cmap='RdYlGn_r',
                   center=0.2, vmin=0, vmax=0.5, ax=ax,
                   cbar_kws={'label': 'Diferencia (%)'})
        
        ax.set_title('Impacto de Offset: Producto × Nivel de Offset',
                    fontsize=14, fontweight='bold')
        ax.set_xlabel('Offset', fontweight='bold', fontsize=12)
        ax.set_ylabel('Producto', fontweight='bold', fontsize=12)
        
        plt.tight_layout()
        output_file = self.output_dir / 'heatmap_producto_offset.png'
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        print(f"✓ Guardado: {output_file}")
        plt.close()
    
    def generate_report(self):
        """
        Genera reporte final
        """
        print("\nGenerando reporte...")
        
        report = []
        report.append("="*80)
        report.append("REPORTE: ANÁLISIS DE IMPACTO DE OFFSET EN PREDICCIONES NIR")
        report.append("="*80)
        report.append("")
        
        report.append("CONFIGURACIÓN DEL ESTUDIO:")
        report.append(f"  • Niveles de offset evaluados: {len(self.offsets)}")
        report.append(f"  • Rango de offset: {min(self.offsets):.3f} - {max(self.offsets):.3f}")
        report.append(f"  • Productos: {len(self.productos)} ({', '.join(self.productos)})")
        report.append(f"  • Parámetros por producto: {len(self.parametros)}")
        report.append(f"  • Total comparaciones: {len(self.results)}")
        report.append("")
        
        report.append("RESULTADOS GLOBALES:")
        report.append("-"*80)
        report.append(self.summary.to_string(index=False))
        report.append("")
        
        report.append("LÍMITES RECOMENDADOS:")
        report.append("-"*80)
        
        # Encontrar límites
        bp_02 = self.find_breakpoint(threshold=0.2, min_percentage=75)
        bp_03 = self.find_breakpoint(threshold=0.3, min_percentage=90)
        
        if bp_02:
            report.append(f"\nPara mantener >75% parámetros con diferencia <0.2%:")
            report.append(f"  → Offset máximo recomendado: {bp_02:.3f}")
        
        if bp_03:
            report.append(f"\nPara mantener >90% parámetros con diferencia <0.3%:")
            report.append(f"  → Offset máximo límite: {bp_03:.3f}")
        
        report.append("")
        report.append("="*80)
        
        # Guardar reporte
        report_text = "\n".join(report)
        output_file = self.output_dir / 'reporte_impacto_offset.txt'
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report_text)
        
        print(report_text)
        print(f"\n✓ Reporte guardado: {output_file}")
    
    def run_complete_analysis(self):
        """
        Ejecuta análisis completo
        """
        print("\n" + "="*80)
        print("ANÁLISIS COMPLETO DE IMPACTO DE OFFSET")
        print("="*80)
        
        self.load_data()
        self.calculate_differences()
        self.analyze_impact()
        self.plot_main_curve()
        self.plot_by_product()
        self.plot_heatmap()
        self.generate_report()
        
        print("\n" + "="*80)
        print("✓ ANÁLISIS COMPLETADO")
        print("="*80)


# EJEMPLO DE USO
if __name__ == "__main__":
    
    # Inicializar analizador
    analyzer = OffsetImpactAnalyzer(
        data_file='datos_offset_study.xlsx',
        output_dir='outputs_offset_study'
    )
    
    # Ejecutar análisis completo
    analyzer.run_complete_analysis()
    
    print("\nArchivos generados:")
    print("  • diferencias_detalladas.xlsx")
    print("  • resumen_por_offset.xlsx")
    print("  • analisis_offset_principal.png")
    print("  • analisis_offset_por_producto.png")
    print("  • heatmap_producto_offset.png")
    print("  • reporte_impacto_offset.txt")
